﻿using UnityEngine;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using System;

public class OvrAvatarPacket
{
    public IntPtr ovrNativePacket = IntPtr.Zero;
}
