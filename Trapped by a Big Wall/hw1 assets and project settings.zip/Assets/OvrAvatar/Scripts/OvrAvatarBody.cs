﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class OvrAvatarBody : MonoBehaviour
{
    public virtual void UpdatePose(float voiceAmplitude)
    {
    }
}