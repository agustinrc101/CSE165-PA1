﻿using UnityEngine;

public class OVRLayerAttribute : PropertyAttribute {
}
